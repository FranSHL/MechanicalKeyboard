var btnAbrirModal =
document.querySelector("#btn-abrir-modal");
var btnCerrarModal =
document.querySelector("#btn-cerrar-modal");
var modal =
document.querySelector("#modal");


btnAbrirModal.addEventListener("click",()=>{
    modal.showModal();
    
})
btnCerrarModal.addEventListener("click",()=>{
    modal.close();
    
})