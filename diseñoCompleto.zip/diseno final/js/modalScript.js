function openModal(imageSrc, title, description) {
    document.getElementById("modalImg").src = imageSrc;
    document.getElementById("modalTitle").textContent = title;
    document.getElementById("modalDescription").textContent = description;
    document.getElementById("myModal").style.display = "flex";
}

function closeModal() {
    document.getElementById("myModal").style.display = "none";
}

// Cerrar modal solo si se hace clic fuera del contenido
document.getElementById("myModal").addEventListener("click", function(event) {
    // Verifica si el clic fue en el fondo del modal (fuera del contenido)
    if (event.target === document.getElementById("myModal")) {
        closeModal();
    }
});