let teclas = [
  "1", "2", "3", "4", "5", "6", "7", "8", "9", "0",
  "q", "w", "e", "r", "t", "y", "u", "i", "o", "p",
  "a", "s", "d", "f", "g", "h", "j", "k", "l", "ñ",
  "z", "x", "c", "v", "b", "n", "m", ",", ".", "-"
];

let teclado = document.querySelector("#teclado");

teclas.forEach(tecla => {
  let div = document.createElement("div");
  div.classList.add("tecla");
  div.textContent = tecla;
  teclado.appendChild(div);
});

document.addEventListener("keydown", e => {
  let teclaPresionada = e.key;
  let tecla = document.querySelector(`.tecla:contains(${teclaPresionada})`);
  if (tecla) {
    tecla.classList.add("presionada");
  }
});

document.addEventListener("keyup", e => {
  let teclaPresionada = e.key;
  let tecla = document.querySelector(`.tecla:contains(${teclaPresionada})`);
  if (tecla) {
    tecla.classList.remove("presionada");
  }
});

let botonesCambioColor = document.querySelector("#botones-cambio-color");

let colores = ["#FF0000", "#00FF00", "#0000FF", "#FFFF00", "#FF00FF"];

colores.forEach(color => {
  let boton = document.createElement("button");
  boton.classList.add("boton-color");
  boton.style.backgroundColor = color;
  boton.addEventListener("click", () => {
    let teclas = document.querySelectorAll(".tecla");
    teclas.forEach(tecla => {
      tecla.style.backgroundColor = color;
    });
  });
  botonesCambioColor.appendChild(boton);
});
