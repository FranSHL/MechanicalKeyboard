// Selecciona los elementos necesarios
const slides = document.querySelectorAll('.carousel-slide');
const indicators = document.querySelectorAll('.carousel-indicator');

// Variable para rastrear la imagen actual
let currentIndex = 0;

// Función para mostrar una imagen específica
function showSlide(index) {
    // Oculta todas las imágenes
    slides.forEach((slide, i) => {
        slide.style.display = i === index ? 'block' : 'none';
    });

    // Actualiza los indicadores
    indicators.forEach((indicator, i) => {
        indicator.style.backgroundColor = i === index ? '#E83D61' : '#CED8E1';
    });
}

// Función para avanzar al siguiente slide
function nextSlide() {
    currentIndex = (currentIndex + 1) % slides.length; // Cicla al siguiente slide
    showSlide(currentIndex);
}

// Muestra el primer slide al cargar la página
showSlide(currentIndex);

// Cambia de imagen cada 3 segundos
setInterval(nextSlide, 3000);
