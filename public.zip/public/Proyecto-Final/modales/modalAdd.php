    <div class="modal fade" id="agregarEmpleadoModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5 titulo_modal">Registrar Nuevo Producto</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="formularioEmpleado" action="" method="POST" autocomplete="off">
                        <div class="mb-3">
                            <label class="form-label">Titulo</label>
                            <input type="text" name="titulo" class="form-control" required />
                        </div>
                        
                        <div class="row">
                            <div class="mb-6">
                                <label class="form-label">Perecio</label>
                                <input type="number" name="precio" class="form-control" required />
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Descripcion</label>
                                <input type="text" name="descripcion" class="form-control" required />
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Imagen</label>
                                <input type="text" name="urlImg" class="form-control" required />
                            </div>

                        <div class="d-grid gap-2">
                        
                            <button type="submit" class="btn btn-primary btn_add" onclick="window.addNuevoEmpleado(event)">
                                Registrar nuevo producto
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>