var botonesAgregar = document.querySelectorAll(".añadir-carrito");

botonesAgregar.forEach((boton) => {
boton.addEventListener("click", () => {
alert("Producto agregado al carrito");
});
});